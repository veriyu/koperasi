--
-- Database: `koperasi`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

DROP TABLE IF EXISTS `akun`;
CREATE TABLE `akun` (
  `id_akun` int(5) NOT NULL,
  `no_akun` varchar(15) DEFAULT NULL,
  `nama_akun` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`id_akun`, `no_akun`, `nama_akun`) VALUES
(1, '100', 'Kas'),
(2, '460', 'Simpanan SS'),
(3, '500', 'Simpanan Pokok'),
(4, '510', 'Simpanan Wajib'),
(5, '520', 'Angsuran'),
(6, '600', 'Bunga Pinjaman'),
(7, '603', 'Service Fee'),
(8, '604', 'Uang Pangkal'),
(9, '619', 'Pend Lain-lain');

-- --------------------------------------------------------

--
-- Table structure for table `anggota`
--

DROP TABLE IF EXISTS `anggota`;
CREATE TABLE `anggota` (
  `id_anggota` int(4) UNSIGNED ZEROFILL NOT NULL,
  `no_anggota` varchar(10) DEFAULT NULL,
  `nama_anggota` varchar(45) DEFAULT NULL,
  `no_telpon` varchar(15) DEFAULT NULL,
  `alamat` text,
  `status` int(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(15) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `anggota`
--

INSERT INTO `anggota` (`id_anggota`, `no_anggota`, `nama_anggota`, `no_telpon`, `alamat`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(0001, '1', 'HY Sukirdi', NULL, NULL, 1, '2017-01-14 17:50:40', NULL, '2017-01-14 17:50:40', NULL),
(0002, '2', 'E Sukmana', NULL, NULL, 1, '2017-01-14 17:50:40', NULL, '2017-01-14 17:50:40', NULL),
(0003, '3', 'B Suwito', NULL, NULL, 1, '2017-01-14 17:50:40', NULL, '2017-01-14 17:50:40', NULL),
(0004, '4', 'C Agus M', NULL, NULL, 1, '2017-01-14 17:50:40', NULL, '2017-01-14 17:50:40', NULL),
(0005, '5', 'L Triyulianto', NULL, NULL, 1, '2017-01-14 17:50:40', NULL, '2017-01-14 17:50:40', NULL),
(0006, '7', 'E Sareng', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0007, '8', 'ST Maryono', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0008, '9', 'M Benyamin', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0009, '10', 'O Siahaan', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0010, '12', 'D Maryanto', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0011, '14', 'Yohanes K', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0012, '16', 'YB Srimulyo', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0013, '17', 'Johanes Wigo S', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0014, '18', 'B Edi Nurhadi', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0015, '19', 'M Sri Handayani', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0016, '20', 'Johanes Wahidin', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0017, '21', 'Antonius Iswahyudi', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0018, '22', 'Dumaria Pakpahan', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0019, '23', 'Calanof A Ginting', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0020, '24', 'Y Totok', NULL, NULL, 1, '2017-01-14 17:50:41', NULL, '2017-01-14 17:50:41', NULL),
(0021, '28', 'Hendra Kurniawan', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0022, '29', 'Rita Hermawati', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0023, '30', 'A Hary Siswanto', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0024, '31', 'Y Gracias B', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0025, '32', 'FX Frediyono', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0026, '34', 'Diah Endah A', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0027, '35', 'D Dwi Wahyono', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0028, '36', 'VY Gung Supriyadi', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0029, '38', 'M Supriyadi', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0030, '39', 'Sri Sumarsiwi T', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0031, '40', 'F Suyatmi', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0032, '41', 'Pintar Samosir', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0033, '44', 'Sukatno', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0034, '45', 'Windarsih', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0035, '46', 'A Astanta', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0036, '48', 'Hatilita Teodora Dachi', NULL, NULL, 1, '2017-01-14 17:50:42', NULL, '2017-01-14 17:50:42', NULL),
(0037, '50', 'Yohanes Samijo', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0038, '51', 'Yohanita Murniningsih', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0039, '55', 'L Rormaida Harianja', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0040, '57', 'Dwi Nastiti', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0041, '58', 'Sri Ningsih', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0042, '60', 'Kartini', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0043, '61', 'Suherman Sudarsono', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0044, '63', 'Juannara Wijaya W', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0045, '65', 'Elisabeth Sri Kurniasih', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0046, '66', 'Tetty Situmorang', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0047, '67', 'Risma', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0048, '71', 'Romanus', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0049, '72', 'Y Yenny Kumala Dewi', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0050, '73', 'F Mario Pratama', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0051, '74', 'Helen Theresia', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0052, '75', 'Tiara', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0053, '76', 'Edindo Marlanus Sinaga', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0054, '77', 'K Ruktini Banundari', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0055, '78', 'A Suratno', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0056, '79', 'Margaretha Balusu', NULL, NULL, 1, '2017-01-14 17:50:43', NULL, '2017-01-14 17:50:43', NULL),
(0057, '80', 'Hendrikus Andi W', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0058, '81', 'Suparman', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0059, '82', 'Rosmawati Malau', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0060, '83', 'Maria Theresia W', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0061, '84', 'Leonardus Dandy W', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0062, '87', 'Benny Afandy M', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0063, '88', 'Nanto', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0064, '90', 'Marcellus Eko P', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0065, '92', 'Dony Gultom', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0066, '94', 'Gatot Sudi Pratama', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0067, '95', 'Siti Komariah', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0068, '96', 'Oca Bertho', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0069, '97', 'Yustina Endang Sri W', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0070, '99', 'Wahyu Joko Nugroho', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0071, '100', 'Egeun Lastviningsih', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0072, '101', 'Andreas Koko A', NULL, NULL, 1, '2017-01-14 17:50:44', NULL, '2017-01-14 17:50:44', NULL),
(0073, '102', 'Muryanto', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0074, '103', 'Yohanes Aldy Krisna', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0075, '104', 'Emeliana Tumini', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0076, '105', 'Untung Andreas', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0077, '106', 'Sri Yani', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0078, '107', 'Mahmudi', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0079, '108', 'Kristina Zilizu', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0080, '109', 'Muliahati Ziliwu', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0081, '110', 'Regina Hermawasih', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0082, '112', 'FX Martono', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0083, '113', 'Krisnanto', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0084, '114', 'Rexi Simbolon', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0085, '115', 'Resly Sinaga', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0086, '116', 'Anandoa Amajihono', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0087, '118', 'Anna Nur Widayati', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0088, '119', 'Cucu Rosmaya', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0089, '120', 'Theresia Wijilestari', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0090, '123', 'Yohanes Kresna SN', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0091, '124', 'Yohanes Yudo P', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0092, '125', 'Larmo', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0093, '126', 'Agnes Shakuntala BS', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0094, '127', 'R Etty Kuswardani', NULL, NULL, 1, '2017-01-14 17:50:45', NULL, '2017-01-14 17:50:45', NULL),
(0095, '128', 'Warid', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0096, '129', 'Saeful Bahri', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0097, '131', 'MC Sumartono', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0098, '132', 'Nyai Endarwilis', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0099, '133', 'Yosafat P Hastoko', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0100, '135', 'Ayi Nisnandar', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0101, '136', 'Laksmi Dyah R', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0102, '137', 'H Djoned Suryanto', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0103, '138', 'Lusiana Tutik', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0104, '139', 'Hermanto', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0105, '141', 'Yuli Kwartolo', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0106, '142', 'Enah Kartinah', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0107, '143', 'Roselina Dwi Adpeni', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0108, '144', 'Th Sulastri', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0109, '145', 'Timbul Wahyuna', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0110, '146', 'Ferry Yousandy ST', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0111, '147', 'Daniel Christian W', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0112, '148', 'Hestiyani', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0113, '149', 'Dedeh Wiswaniroch A', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0114, '150', 'Tami Purwaningsih', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0115, '151', 'FX Sumardi', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0116, '152', 'Maruly', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0117, '153', 'Ng Sun Lie', NULL, NULL, 1, '2017-01-14 17:50:46', NULL, '2017-01-14 17:50:46', NULL),
(0118, '154', 'Febrianty Diah Pratiwi', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0119, '155', 'Rosza Claudia Magdalena', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0120, '156', 'Hotmaida', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0121, '162', 'Dyara Gita', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0122, '163', 'Sri Harlistiani', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0123, '164', 'Bryan Gregorius Manao', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0124, '165', 'Vincentius Dachi', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0125, '166', 'Sumirah', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0126, '167', 'Deciderius Pudiastana', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0127, '168', 'Lili Fransiska', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0128, '169', 'Ratningsih', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0129, '170', 'kastinah', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0130, '171', 'Suratmi', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0131, '172', 'Tasori', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0132, '173', 'Septa Muhamad Lail P', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0133, '174', 'Isbandiyah', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0134, '175', 'Endah Rachmawati', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0135, '176', 'Endah Yulianti', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0136, '177', 'Riza Ariviyani', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0137, '178', 'Susetyaningsih', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0138, '179', 'Emilia Mariamah Dachi', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0139, '180', 'Lindaria Tambunan', NULL, NULL, 1, '2017-01-14 17:50:47', NULL, '2017-01-14 17:50:47', NULL),
(0140, '181', 'Mariani Simboro', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0141, '182', 'Purida Sianturi', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0142, '183', 'Paulus Margiono', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0143, '184', 'Jiyo', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0144, '185', 'Darawdi', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0145, '186', 'Erna Delita', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0146, '187', 'Bertauli Manihuruk', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0147, '188', 'Clara Bennita', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0148, '189', 'Minora Tobing', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0149, '190', 'Yarniati Ziliwu', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0150, '191', 'Eni Wulandari', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0151, '192', 'Husor B Pakpahan', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0152, '193', 'Ruminah', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0153, '194', 'Supihartini', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0154, '195', 'Sulastri', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0155, '196', 'Sukardi', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0156, '197', 'M Maskhuri', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0157, '198', 'Dwi Minarni', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0158, '199', 'Mauritius Kurniawan P', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0159, '200', 'Dita Widyasastra SH', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0160, '201', 'Anastasia Bevi Nani Sri M', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0161, '202', 'Vincentius F Suhartono', NULL, NULL, 1, '2017-01-14 17:50:48', NULL, '2017-01-14 17:50:48', NULL),
(0162, '203', 'Vincentia Louva T', NULL, NULL, 1, '2017-01-14 17:50:49', NULL, '2017-01-14 17:50:49', NULL),
(0163, '204', 'Sandra Lestari', NULL, NULL, 1, '2017-01-14 17:50:49', NULL, '2017-01-14 17:50:49', NULL),
(0164, '205', 'Soedjati Sri Soekamti', NULL, NULL, 1, '2017-01-14 17:50:49', NULL, '2017-01-14 17:50:49', NULL),
(0165, '206', 'Uun Rahayu SE', NULL, NULL, 1, '2017-01-14 17:50:49', NULL, '2017-01-14 17:50:49', NULL),
(0166, '207', 'Agus Sutartomo', NULL, NULL, 1, '2017-01-14 17:50:49', NULL, '2017-01-14 17:50:49', NULL),
(0167, '208', 'Mohamad Fauzi', NULL, NULL, 1, '2017-01-14 17:50:49', NULL, '2017-01-14 17:50:49', NULL),
(0168, '209', 'Joko Triyanto', NULL, NULL, 1, '2017-01-14 17:50:49', NULL, '2017-01-14 17:50:49', NULL),
(0169, '210', 'Marcelina Evany P', NULL, NULL, 1, '2017-01-14 17:50:49', NULL, '2017-01-14 17:50:49', NULL),
(0170, '211', 'Nova Yoga Hantrias', NULL, NULL, 1, '2017-01-14 17:50:49', NULL, '2017-01-14 17:50:49', NULL),
(0171, '212', 'Karyaman Ziliwu', NULL, NULL, 1, '2017-01-14 17:50:49', NULL, '2017-01-14 17:50:49', NULL),
(0172, '213', 'Arman Ziliwu', NULL, NULL, 1, '2017-01-14 17:50:49', NULL, '2017-01-14 17:50:49', NULL),
(0173, '214', 'Aulysius Sumardiyono', NULL, NULL, 1, '2017-01-14 17:50:49', NULL, '2017-01-14 17:50:49', NULL),
(0174, '215', 'Yohanes Kristanto Wahyu H', NULL, NULL, 1, '2017-01-14 17:50:49', NULL, '2017-01-14 17:50:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `MenuId` int(5) UNSIGNED ZEROFILL NOT NULL,
  `Nama` varchar(25) DEFAULT NULL,
  `Group` varchar(15) DEFAULT NULL,
  `Parent` int(2) DEFAULT NULL,
  `Child1` int(2) DEFAULT NULL,
  `Child2` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`MenuId`, `Nama`, `Group`, `Parent`, `Child1`, `Child2`) VALUES
(00001, 'Test', '1', 0, NULL, NULL),
(00002, 'Coba', '2', 0, NULL, NULL),
(00003, 'Coba 1', '2', NULL, 2, NULL),
(00004, 'Coba 2', '2', NULL, 2, NULL),
(00005, 'Uji', '3', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2016_09_29_055420_create_cruds_table', 1),
('2014_10_12_000000_create_users_table', 2),
('2014_10_12_100000_create_password_resets_table', 2),
('2016_11_26_185500_create_sessions_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

DROP TABLE IF EXISTS `module`;
CREATE TABLE `module` (
  `Id` int(5) UNSIGNED ZEROFILL NOT NULL,
  `NamaModule` varchar(45) DEFAULT NULL,
  `Keterangan` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`Id`, `NamaModule`, `Keterangan`) VALUES
(00004, 'Anggota', 'Module Anggota'),
(00005, 'Setoran', 'Module Setoran');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8_unicode_ci,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

DROP TABLE IF EXISTS `transaksi`;
CREATE TABLE `transaksi` (
  `id_transaksi` int(4) UNSIGNED ZEROFILL NOT NULL,
  `id_anggota` int(4) DEFAULT NULL,
  `dibayar_ke` varchar(25) DEFAULT NULL,
  `tipe_transaksi` varchar(15) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `no_suk` int(4) DEFAULT NULL,
  `no_sum` int(4) DEFAULT NULL,
  `no_ba` int(4) DEFAULT NULL,
  `keterangan` varchar(45) DEFAULT NULL,
  `jumlah` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` varchar(15) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_anggota`, `dibayar_ke`, `tipe_transaksi`, `tanggal`, `no_suk`, `no_sum`, `no_ba`, `keterangan`, `jumlah`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(0007, 18, NULL, 'MASUK', '2017-01-28', NULL, 123, 18, 'setoran', 1000000, '2017-01-27 21:40:27', 'Aan', '2017-01-28 10:27:08', 'kirdi'),
(0008, 2, NULL, 'MASUK', '2017-01-27', NULL, 33, 2, 'setor', 500000, '2017-01-29 07:04:28', 'Aan', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_detail`
--

DROP TABLE IF EXISTS `transaksi_detail`;
CREATE TABLE `transaksi_detail` (
  `id_transaksi_detail` int(4) UNSIGNED ZEROFILL NOT NULL,
  `id_transaksi` int(4) UNSIGNED DEFAULT NULL,
  `no_akun` int(6) DEFAULT NULL,
  `nilai_d` double DEFAULT NULL,
  `nilai_k` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi_detail`
--

INSERT INTO `transaksi_detail` (`id_transaksi_detail`, `id_transaksi`, `no_akun`, `nilai_d`, `nilai_k`) VALUES
(0055, 7, 100, 1000000, NULL),
(0056, 7, 460, NULL, 950000),
(0057, 7, 500, NULL, NULL),
(0058, 7, 510, NULL, 50000),
(0059, 7, 520, NULL, NULL),
(0060, 7, 600, NULL, NULL),
(0061, 7, 603, NULL, NULL),
(0062, 7, 604, NULL, NULL),
(0063, 7, 619, NULL, NULL),
(0064, 8, 100, 500000, NULL),
(0065, 8, 460, NULL, 250000),
(0066, 8, 500, NULL, NULL),
(0067, 8, 510, NULL, 50000),
(0068, 8, 520, NULL, 200000),
(0069, 8, 600, NULL, NULL),
(0070, 8, 603, NULL, NULL),
(0071, 8, 604, NULL, NULL),
(0072, 8, 619, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `group` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `group`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'super admin', 'Aan', 'yo.dhimas@gmail.com', '$2y$10$wnIhMlu3WBuTYItuEAbgpOlC6Xth8.3gnSdh0V207hz8MpRwrX/hO', 'sgpQ2RYxfguw6SGTUf27Pru6OcspwOliN9fO0kDY3h88O6SwKtcVclEUSzXm', '2016-11-26 11:57:27', '2016-11-26 11:57:27'),
(2, 'admin', 'kirdi', 'kirdi@mail.com', '$2y$10$oYbah90eiCphuIbtumw66.WRty.mnAb8zm3l7k6euydfo3ljRziAG', 'CVvvCL5hdw6f6iwF5Czj64txtZvQFwq23SHEbKDZznVKAbdPN84zZOdiwwVH', '2017-01-14 00:21:40', NULL),
(3, 'super admin', 'agus', 'agustian9129@gmail.com', '$2y$10$ZiXTG8ihJCFErej27ZfFluuQVJI/gennkXT9EZxca0MMkedbbyk2y', NULL, '2017-01-14 08:38:31', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`id_akun`);

--
-- Indexes for table `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`id_anggota`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`MenuId`);

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  ADD PRIMARY KEY (`id_transaksi_detail`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `akun`
--
ALTER TABLE `akun`
  MODIFY `id_akun` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `anggota`
--
ALTER TABLE `anggota`
  MODIFY `id_anggota` int(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=175;
--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `MenuId` int(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `Id` int(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  MODIFY `id_transaksi_detail` int(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
